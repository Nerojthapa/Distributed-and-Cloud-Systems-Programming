package AkkaBankSimulation;

public class Withdrawal {
    public final double amount;

    public Withdrawal(double amount) {
        this.amount = amount;
    }
}