package AkkaBankSimulation;

import akka.actor.AbstractActor;

public class BankAccount extends AbstractActor {
    private double balance = 100.0; // Initial balance
    private static final double MAX_BALANCE = 1000.0;
    private static final double MIN_BALANCE = -1000.0;

    @Override
    public void preStart() {
        System.out.println("Initial Balance: £" + balance);
    }

    @Override
    public Receive createReceive() {
        return receiveBuilder()
                .match(Deposit.class, deposit -> {
                    double newBalance = balance + deposit.amount;
                    if (newBalance <= MAX_BALANCE) {
                        balance = newBalance;
                        System.out.println("Deposited: £" + deposit.amount + " | New Balance: £" + balance);
                    }
                })
                .match(Withdrawal.class, withdrawal -> {
                    if (balance >= withdrawal.amount) {
                        balance -= withdrawal.amount;
                        System.out.println("Withdrawn: £" + withdrawal.amount + " | New Balance: £" + balance);
                    } else {
                        System.out.println("Insufficient balance for withdrawal of £" + withdrawal.amount + " | Current Balance: £" + balance);
                    }
                })
                .build();
    }
}