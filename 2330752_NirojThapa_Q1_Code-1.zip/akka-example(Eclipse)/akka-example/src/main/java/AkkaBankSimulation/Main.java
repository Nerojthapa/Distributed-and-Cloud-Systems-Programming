package AkkaBankSimulation;

import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.actor.Props;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        ActorSystem system = ActorSystem.create("BankSystem");
        ActorRef bankAccount = system.actorOf(Props.create(BankAccount.class), "bankAccount");

        // Generate 10 random transactions
        Random random = new Random();
        double[] transactions = new double[10];
        for (int i = 0; i < transactions.length; i++) {
            transactions[i] = random.nextDouble() * 2001 - 1000; // Values between -1000 and 1000 (inclusive)
        }

        // Send messages to BankAccount actor
        for (double amount : transactions) {
            if (amount > 0) {
                bankAccount.tell(new Deposit(amount), ActorRef.noSender());
            } else if (amount < 0) {
                bankAccount.tell(new Withdrawal(-amount), ActorRef.noSender());
            }
        }

        // Terminate the program after all messages have been processed
        system.terminate();
    }
}